﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MonopolyDemo
{
    // 路径节点
    internal class PathNode
    {
        public string Type { get; set; }
      
    }
}
