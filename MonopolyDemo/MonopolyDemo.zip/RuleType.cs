﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MonopolyDemo
{
    // 规则类型

    // rule1 随机选出投掷顺序
    internal class Rule1
    {
        public void setOperationSequence() { 
        
        }
    }
}
