﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MonopolyDemo
{
    // 节点类型
    internal class NodeType
    {
        public string Type { get; set; }
    }
}
