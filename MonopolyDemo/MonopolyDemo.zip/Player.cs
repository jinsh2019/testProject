﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MonopolyDemo
{
    internal class Player
    {
        public string Name { get; set; }
        public int Sequence { get; set; }

        public int Position { get; set; } = 0;
        public bool canThrow { get; set; } = true;
    }
}
